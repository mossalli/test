public interface D {

    int cc();

    String kk();
}
