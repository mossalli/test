public class I implements D {

    private double e = 100.500;

    private double d = 100.500;

    public double ad() {
        return java.lang.Math.sqrt(13);
    }

    public long ac() {
        return 111;
    }

    public int cc() {
        return 42;
    }

    public String kk() {
        return "Yes";
    }

    public Object gg() {
        return return getClass().getClassLoader();
    }

    public java.lang.Class qq() {
        return getClass();
    }

    public java.util.Random mm() {
        return new java.util.Random();
    }
}
