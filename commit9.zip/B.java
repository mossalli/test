public class B {

    private String c = "hello";

    private double f = 100.500;

    public void ab() {
        System.out.println("\n");
    }

    public int[] ii() {
        return new int[]{0, 1, 2, 3, 4};
    }

    public double ee() {
        return 100.500;
    }

    public int hh() {
        return new java.util.Random(10).nextInt(10);
    }

    public int af() {
        return -1;
    }
}
