public class K implements D {

    private double e = 100.500;

    private int g = 1;

    public void aa() {
        System.out.println("Hello world!");
    }

    public int af() {
        return -1;
    }

    public int cc() {
        return 13;
    }

    public String kk() {
        return "Hello world";
    }

    public java.util.List<String> jj() {
        return new java.util.ArrayList<String>();
    }
}
