public class D extends null {

    int cc();

    String kk();

    public void aa() {
        return;
    }

    public java.util.Set<Integer> ll() {
        return new java.util.LinkedList<Integer>;
    }
}
