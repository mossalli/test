public class D extends null {

    int cc();

    String kk();

    public int[] ii() {
        return new int[]{4, 3, 2, 1};
    }
}
