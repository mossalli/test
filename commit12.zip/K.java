public class K extends null implements D {

    private double e = 100.500;

    private int g = 1;

    public void aa() {
        System.out.println("Hello world!");
    }

    public int af() {
        return -1;
    }

    public int cc() {
        return 13;
    }

    public String kk() {
        return "Hello world";
    }

    public java.util.List<String> jj() {
        return new java.util.LinkedList<String>();
    }

    public java.util.Random mm() {
        return new java.util.Random();
    }

    public int hh() {
        return new java.util.Random(10).nextInt(10);
    }

    public Object gg() {
        return new java.util.Random();
    }

    public long dd() {
        return 100500;
    }
}
