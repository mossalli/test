public class D extends null {

    int cc();

    String kk();
}
